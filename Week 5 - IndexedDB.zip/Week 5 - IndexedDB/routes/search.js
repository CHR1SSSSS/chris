var express = require('express');
var router = express.Router();

/* GET home page. */


router.get('/', function(req, res, next) {
    res.render('search', { title: 'Music festival selfie picture' });
});

/**
 *  POST the data about the weather.
 *  parameters in body:
 *    location: a City Id
 *    date: a date
 */
router.post('/search', function(req, res, next) {
    // get random weather for a location
    const selfieData= getSelfieData(req.body.name, req.body.date);
    res.setHeader('Content-Type', 'application/json');
    res.send(JSON.stringify(selfieData));

});


// const CLOUDY= 0;
// const CLEAR=1;
// const RAINY=2;
// const OVERCAST=3;
// const SNOWY=4;

/**
 *
 * @param location
 * @param forecast (cloudy, etc.)
 * @param temperature
 * @param wind
 * @param precipitation
 * @constructor
 */
class SelfieData{
    constructor (name, date, location, picture, describe) {
        this.name= name;
        this.date= date;

        this.location=location;
        this.picture= picture;

        this.describe= describe;
    }
}

/**
 * given a city and a date, it generates random values for the forecast
 * @param name
 * @param date
 * @returns {SelfieData}
 */
function getSelfieData(name, date, location,picture,describe) {
    return new SelfieData(
        name,
        // date
        date,
        //location
        location,

        picture,

        describe);

}


// function randomIntFromInterval(min,max) {
//     return Math.floor(Math.random()*(max-min+1)+min);
// }


module.exports = router;
