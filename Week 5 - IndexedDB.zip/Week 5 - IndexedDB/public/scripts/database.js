////////////////// DATABASE //////////////////
// the database receives from the server the following structure
/** class WeatherForecast{
 *  constructor (location, date, forecast, temperature, wind, describe) {
 *    this.location= location;
 *    this.date= date,
 *    this.forecast=forecast;
 *    this.temperature= temperature;
 *    this.wind= wind;
 *    this.describe= describe;
 *  }
 *}
 */
var dbPromise;

const PWA_DB_NAME= 'db_PWA_1';
const PWA_STORE_NAME= 'store_user';

/**
 * it inits the database
 */
function initSelfieData(){
    dbPromise = idb.openDb(PWA_DB_NAME, 1, function (upgradeDb) {
        if (!upgradeDb.objectStoreNames.contains(PWA_STORE_NAME)) {
            var selfieDB = upgradeDb.createObjectStore(PWA_STORE_NAME, {keyPath: 'id', autoIncrement: true});
            selfieDB.createIndex('name', 'name', {unique: false, multiEntry: true});
        }
    });
}
/**
 * it saves the forecasts for a name in localStorage
 * @param name
 * @param userObject
 */
function storeCachedData(name, userObject) {
    console.log('inserting: '+JSON.stringify(userObject));
    if (dbPromise) {
        dbPromise.then(async db => {
            var tx = db.transaction(PWA_STORE_NAME, 'readwrite');
            var store = tx.objectStore(PWA_STORE_NAME);
            await store.put(userObject);
            return tx.complete;
        }).then(function () {
            console.log('added item to the store! '+ JSON.stringify(userObject));
        }).catch(function (error) {
            localStorage.setItem(name, JSON.stringify(userObject));
        });
    }
    else localStorage.setItem(name, JSON.stringify(userObject));
}


/**
 * it retrieves the forecasts data for a name from the database
 * @param name
 * @param date
 * @returns {*}
 */
function getCachedData(name, date) {
    if (dbPromise) {
        dbPromise.then(function (db) {
            console.log('fetching: '+name);
            var tx = db.transaction(PWA_STORE_NAME, 'readonly');
            var store = tx.objectStore(PWA_STORE_NAME);
            var index = store.index('name');
            return index.getAll(IDBKeyRange.only(name));
        }).then(function (readingsList) {
            if (readingsList && readingsList.length>0){
                var max;
                for (var elem of readingsList)
                    if (!max || elem.date>max.date)
                        max= elem;
                if (max) addToResults(max);
            } else {
                const value = localStorage.getItem(name);
                if (value == null)
                    addToResults({name: name, date: date});
                else addToResults(value);
            }
        });
    } else {
        const value = localStorage.getItem(name);
        if (value == null)
            addToResults( {name: name, date: date});
        else addToResults(value);
    }
}


/**
 * given the server data, it returns the value of the describe
 * @param dataR the data returned by the server
 * @returns {*}
 */
function getDescribe(dataR) {
    if (dataR.describe == null && dataR.describe === undefined)
        return "unavailable";
    return dataR.describe
}

/**
 * given the server data, it returns the value of the field wind
 * @param dataR the data returned by the server
 * @returns {*}
 */
// function getWind(dataR) {
//     if (dataR.wind == null && dataR.wind === undefined)
//         return "unavailable";
//     else return dataR.wind;
// }

/**
 * given the server data, it returns the value of the field temperature
 * @param dataR the data returned by the server
 * @returns {*}
 */
function getLocation(dataR) {
    if (dataR.location== null && dataR.location === undefined)
        return "unavailable";
    else return dataR.location;
}


/**
 * the server returns the forecast as a n integer. Here we find out the
 * string so to display it to the user
 * @param forecast
 * @returns {string}
 */
function getPicture(dataR) {
    if (dataR.picture== null && dataR.picture === undefined)
        return "unavailable";
    else return dataR.picture;
}
